# `local-agent-bridge`

Local companion bridge for the WebAgent browser widget.

This package exposes the generic agent endpoints used by the widget and runs the user's own local Codex or Claude agent:

- `/api/codex/status`
- `/api/codex/chat`
- `/api/codex/cancel`
- `/api/claude/status`
- `/api/claude/chat`
- `/api/claude/cancel`
- `/api/db-helper/*`
- `/api/web/*`

## Install

```bash
pip install local-agent-bridge
```

Optional SQL Server support:

```bash
pip install "local-agent-bridge[sqlserver]"
```

## Run

```bash
local-agent-bridge
```

Default address:

- `http://127.0.0.1:8787`

The widget can auto-discover this address by calling:

- `http://127.0.0.1:8787/.well-known/webagent-bridge`

That discovery endpoint returns the active `api_base_url`, so the widget does not need a host page to hardcode `apiBaseUrl`.

## Environment

Copy `.env.example` and set what you need:

- `WEBAGENT_HOST`
- `WEBAGENT_PORT`
- `WEBAGENT_PUBLIC_BASE_URL`
- `WEBAGENT_REQUIRE_APPROVAL`
- `WEBAGENT_BRIDGE_NAME`
- `WEBAGENT_ALLOW_ORIGIN`
- `CODEX_CLI_PATH`
- `CLAUDE_CODE_EXE`
- `CODEX_VERIFY_FINAL`
- `CODEX_AGENT_DOC_PATHS`
- `CODEX_AGENT_INSTRUCTIONS_PATH`
- `SQL_CONN_STR`

## Intended Deployment Model

- Website owners embed `@webagent/widget` in their site.
- If the site does not force its own `apiBaseUrl`, the widget auto-discovers a running `local-agent-bridge` on the user's machine.
- If the site does set `apiBaseUrl`, that site-provided agent wins and the widget uses the site's backend.
- The host page provides a bridge object for page context and safe UI actions.

## Notes

- The browser widget does not run Codex or Claude directly.
- `local-agent-bridge` is the component that talks to local CLI tools.
- New websites must be approved locally before they can use the bridge.
- CORS is controlled by `WEBAGENT_ALLOW_ORIGIN`, but approval is enforced separately per website origin when `WEBAGENT_REQUIRE_APPROVAL=1`.
